import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="preprocessRawText",
    version="0.0.1",
    author="nguyentho",
    author_email="nguyentho0207@gmail.com",
    description="preprocessRawText NLP",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="git@p.zamba.vn:thont/preprocessrawtext.git",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
