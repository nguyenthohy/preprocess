# coding=utf-8

from gensim.parsing.preprocessing import strip_non_alphanum, strip_numeric, split_alphanum, strip_short, \
    strip_multiple_whitespaces

from pyvi import ViTokenizer


class pre_process_raw_text:
    @staticmethod
    def clean_text(self, text=''):
        try:
            contents_parsed = strip_non_alphanum(text).lower().strip()  # Xóa các ký tự đặc biệt
            contents_parsed = strip_numeric(contents_parsed)  # Xóa các ký tự đặc biệt không phải chữ hoặc số
            contents_parsed = split_alphanum(contents_parsed)  # Xóa từ có số và chữ, vd a1 a2
            contents_parsed = ViTokenizer.tokenize(contents_parsed)  # merge compound word
            contents_parsed = strip_short(contents_parsed, minsize=2)  # Xóa các chữ đứng riêng lẻ
            contents_parsed = strip_multiple_whitespaces(contents_parsed)  # Chuẩn hóa để mỗi từ cách nhau một khoảng trắng

            return contents_parsed

        except Exception as e:
            return str(e)

